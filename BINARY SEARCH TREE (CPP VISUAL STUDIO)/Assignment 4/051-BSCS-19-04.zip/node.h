#pragma once
class Node {

private:

	int data;
	Node* leftPtr;
	Node* rightPtr;

public:

	void setdata(int data) { this->data = data; }
	void setleftPtr(Node* leftPtr) { this->leftPtr = leftPtr; }
	void setrightPtr(Node* rightPtr) { this->rightPtr = rightPtr; }
	int getdata() { return data; }
	Node* getleftPtr() { return leftPtr; }
	Node* getrightPtr() { return rightPtr; }

};

