#pragma once
#include<stack>
#include<iostream>
#include"Node.h"
class BST{
private:
	Node* head;

public:

	BST();
	~BST();
	bool insert(int);
	bool remove(int);
	bool find(int);
	void inorder();
	void preorder();
	void postorder();

};

BST::BST() { head = nullptr; }
BST::~BST() {
	std::stack<Node*> Stack;
	std::stack<Node*> data;
	Stack.push(head);
	if (head == nullptr) return;
	while (!Stack.empty()) {
		Node* current = Stack.top();
		Stack.pop();
		data.push(current);
		if (current->getleftPtr()) Stack.push(current->getleftPtr());
		if (current->getrightPtr()) Stack.push(current->getrightPtr());
	}
	while (!data.empty()) {
		delete data.top();
		data.pop();
	}
}
bool BST::insert(int value) {
	Node* newNode = new Node();
	Node* tempRoot = head;
	newNode->setdata(value);
	newNode->setleftPtr(nullptr);
	newNode->setrightPtr(nullptr);
	if (tempRoot == nullptr) return (head = newNode);
	else {
		while (tempRoot!=nullptr){
			if (tempRoot->getdata() >= value) {
				if (tempRoot->getleftPtr() == nullptr) {
					tempRoot->setleftPtr(newNode);
					return true;
				}
				else tempRoot = tempRoot->getleftPtr();
			}
			else if (tempRoot->getdata() < value) {
				if (tempRoot->getrightPtr() == nullptr) {
					tempRoot->setrightPtr(newNode);
					return true;
				}
				else tempRoot = tempRoot->getrightPtr();
			}
		}
	}
	return false;
}
bool BST::remove(int value) {
	Node* root = head;
	Node* parentNode = nullptr;
	if (root == nullptr) return false;
	do {
		if (value == root->getdata()) {
			Node* toSet = nullptr;
			if (!root->getleftPtr() || !root->getrightPtr()) toSet = (root->getleftPtr() == nullptr ? root->getrightPtr() : root->getleftPtr());
			else {
				Node* greatestNode = root->getleftPtr();
				Node* parentOfGreatest = nullptr;
				while (greatestNode != nullptr) {
					if(greatestNode->getrightPtr()!= nullptr) parentOfGreatest = greatestNode;
					greatestNode = greatestNode->getrightPtr();
				}
				greatestNode = parentOfGreatest->getrightPtr();
				parentOfGreatest->setrightPtr(nullptr);
				greatestNode->setrightPtr(root->getrightPtr());
				greatestNode->setleftPtr(root->getleftPtr());
				toSet = greatestNode;
				if (parentNode == nullptr) return (head = toSet);
			}
			(value > parentNode->getdata() ? parentNode->setrightPtr(toSet) : parentNode->setleftPtr(toSet));
			delete root;
			return true;
		}
		parentNode = root;
		root = (value > root->getdata() ? root->getrightPtr() : root->getleftPtr());
	} while (root);
	return false;
}
bool BST::find(int value) {
	Node* parentNode = head;
	while (parentNode != nullptr) {
		if (parentNode->getdata() == value) return true;
		else if (parentNode->getdata() > value) parentNode = parentNode->getrightPtr();
		else parentNode = parentNode->getleftPtr();
	}
	return false;
}
void BST::inorder() {
	std::stack<Node*> Stack;
	Node* root = head;
	while(true){
		if (root != nullptr) {
			Stack.push(root);
			root = root->getleftPtr();
		}
		else {
			if (Stack.empty()) return;
			root = Stack.top();
			std::cout << root->getdata() << " ";
			Stack.pop();
			root = root->getrightPtr();
		}
	}
}
void BST::preorder() {
	std::stack<Node*> Stack;
	Node* root = head;
	if (root == nullptr) return;
	while (true) {
		if (root != nullptr) {
			std::cout << root->getdata() << " ";
			Stack.push(root);
			root = root->getleftPtr();
		}
		else {
			if (Stack.empty()) return;
			root = Stack.top()->getrightPtr();
			Stack.pop();
		}
	}
}
void BST::postorder() {
	std::stack<Node*> Stack;
	std::stack<int> data;
	Stack.push(head);
	if (head == nullptr) return;
	while (!Stack.empty()) {
		Node* current = Stack.top();
		Stack.pop();
		data.push(current->getdata());
		if (current->getleftPtr()) Stack.push(current->getleftPtr());
		if (current->getrightPtr()) Stack.push(current->getrightPtr());
	}
	while (!data.empty()) {
		std::cout << data.top() << " ";
		data.pop();
	}
}


