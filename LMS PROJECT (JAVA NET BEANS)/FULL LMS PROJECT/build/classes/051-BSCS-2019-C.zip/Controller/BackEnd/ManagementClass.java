package Controller.BackEnd;

@SuppressWarnings("serial")
public class ManagementClass extends UsersClass {

    public ManagementClass ( String jobStatus , String name , String Cnic , DataClass data ) {
        super ( name , Cnic , jobStatus , data );
    }
}
