/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author hp
 */
public class CustomOrderClass {
     public int customOrderId;
    public String Description;
    public String customProductType;

    public int getCustomOrderId() {
        return customOrderId;
    }

    public void setCustomOrderId(int customOrderId) {
        this.customOrderId = customOrderId;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getCustomProductType() {
        return customProductType;
    }

    public void setCustomProductType(String customProductType) {
        this.customProductType = customProductType;
    }
    
    
}
