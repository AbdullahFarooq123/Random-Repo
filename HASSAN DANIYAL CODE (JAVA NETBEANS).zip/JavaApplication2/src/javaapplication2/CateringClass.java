/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author hp
 */
public class CateringClass {
    
     public int cateringOrderId;

    public int getCateringOrderId() {
        return cateringOrderId;
    }

    public void setCateringOrderId(int cateringOrderId) {
        this.cateringOrderId = cateringOrderId;
    }

    public String getCaterindAddress() {
        return caterindAddress;
    }

    public void setCaterindAddress(String caterindAddress) {
        this.caterindAddress = caterindAddress;
    }
   
    public String caterindAddress;
}
