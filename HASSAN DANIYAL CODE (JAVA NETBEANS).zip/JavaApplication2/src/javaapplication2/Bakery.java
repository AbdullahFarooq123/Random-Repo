/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author hp
 */
import java.util.ArrayList;
import java.util.HashMap;

 public class Bakery {
    private String address;
    private int bakeryId;
    private String bakeryName;
    public ArrayList<Employee> employees=new ArrayList<Employee>();
    private ArrayList<Product> products=new ArrayList<Product>();
    private ArrayList<Customer> regularCustomers=new ArrayList<>();
    private HashMap<String,String> login=new HashMap<String,String>();
    private ArrayList<String> complaints=new ArrayList<>();

    public HashMap<String, String> getLogin() {
        return login;
    }
    public void addProduct(Product product)
    {
        for(Product p:products)
            if(product.getName().equalsIgnoreCase(p.getName()))
                System.out.println("Product Is Already In Inventory");
        else {
            products.add(product);
        }
    }
    public void removeProduct(Product product)
    {
        try{
            products.remove(product);
        }
        catch (Exception e)
        {
            System.out.println("Product is Not In Inventory");
        }
    }
    public void addEmployee(Employee employee)
    {
        employees.add(employee);
    }
    public void productsList()
    {
        for(Product p:products)
            System.out.println(p.getName());
    }
    public void Complaint(String complaint){
       complaints.add(complaint);
    }

    public void setBakeryId(int bakeryId) {
        this.bakeryId = bakeryId;
    }

    public int getBakeryId() {
        return bakeryId;
    }

    public String getBakeryName() {
        return bakeryName;
    }

    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    public void setBakeryName(String bakeryName) {
        this.bakeryName = bakeryName;
    }

    public void setEmployees(ArrayList<Employee> employees) {
        this.employees = employees;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}

