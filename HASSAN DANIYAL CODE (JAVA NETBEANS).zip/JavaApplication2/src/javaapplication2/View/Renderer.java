/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2.View;

import java.awt.Component;
import java.util.ArrayList;
import javaapplication2.Product;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author hp
 */
public class Renderer extends DefaultTableCellRenderer {
    ArrayList<ImageIcon> images=new ArrayList<>();
    
    
    
    
    
    public Component getTableCellRendererComponent(JTable table,Object value,boolean isSelected,boolean hasFocus,int row,int column) {
        JLabel jlabel=new JLabel();
        for(Product pro : MangeProducts.products)
    {
       images.add(new ImageIcon(pro.getImage()));
       
    }
        jlabel.setIcon(images.get(row));
        return jlabel;
                }
    
}
