/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author hp
 */
public class DiscountClass {
       static int cakeDisount;
     static int sweetsDisount;
     static int drinksDisount;
     static int pasteriesDisount;

    public static int getCakeDisount() {
        return cakeDisount;
    }

    public static void setCakeDisount(int cakeDisount) {
        DiscountClass.cakeDisount = cakeDisount;
    }

    public static int getSweetsDisount() {
        return sweetsDisount;
    }

    public static void setSweetsDisount(int sweetsDisount) {
        DiscountClass.sweetsDisount = sweetsDisount;
    }

    public static int getDrinksDisount() {
        return drinksDisount;
    }

    public static void setDrinksDisount(int drinksDisount) {
        DiscountClass.drinksDisount = drinksDisount;
    }

    public static int getPasteriesDisount() {
        return pasteriesDisount;
    }

    public static void setPasteriesDisount(int pasteriesDisount) {
        DiscountClass.pasteriesDisount = pasteriesDisount;
    }
}
