/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.io.Serializable;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author hp
 */
public class Product implements Serializable{
    private String name;
    private int productBuyingPrice;
    private int productSellingPrice;
    private int quantities;
    private int productId;
    private int productsCounter;
    private String imagePath;
    private String category;
    private ImageIcon icon;
    private int enteredQuantity;

    public int getEnteredQuantity() {
        return enteredQuantity;
    }

    public void setEnteredQuantity(int enteredQuantity) {
        this.enteredQuantity = enteredQuantity;
    }
    

    public ImageIcon getIcon() {
        return icon;
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getImage() {
        return imagePath;
    }

    public void setImage(String image) {
       imagePath = image;
    }
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getProductBuyingPrice() {
        return productBuyingPrice;
    }

    public void setProductBuyingPrice(int productBuyingPrice) {
        this.productBuyingPrice = productBuyingPrice;
    }

    public int getProductSellingPrice() {
        return productSellingPrice;
    }

    public void setProductSellingPrice(int productSellingPrice) {
        this.productSellingPrice = productSellingPrice;
    }

    public int getQuantities() {
        return quantities;
    }

    public void setQuantities(int quantities) {
        this.quantities = quantities;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getProductsCounter() {
        return productsCounter;
    }

    public void setProductsCounter(int productsCounter) {
        this.productsCounter = productsCounter;
    }
}

